"use client"

import { AlertTriangle, X } from "lucide-react"
import { Button } from "@/components/ui/button"

interface WarningModalProps {
  onAccept: () => void
  onDismiss?: () => void
}

export default function WarningModal({ onAccept, onDismiss }: WarningModalProps) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm">
      <div className="bg-card border border-border/50 rounded-2xl p-8 max-w-md mx-4 animate-fade-in relative">
        {onDismiss && (
          <button onClick={onDismiss} className="absolute top-4 left-4 p-1 hover:bg-muted rounded transition-colors">
            <X size={20} className="text-muted-foreground" />
          </button>
        )}

        <div className="flex items-center gap-3 mb-4">
          <AlertTriangle className="text-yellow-500" size={28} />
          <h2 className="text-2xl font-bold">تحذير من الحرق</h2>
        </div>

        <p className="text-foreground/90 mb-4 leading-relaxed">
          هذه الصفحة تحتوي على معلومات عن الشخصيات قد تكشف أجزاء مهمة من القصة والأحداث المستقبلية.
        </p>

        <div className="bg-yellow-500/10 border border-yellow-500/20 rounded-lg p-3 mb-6">
          <p className="text-sm text-yellow-600 dark:text-yellow-400">
            ننصحك بقراءة جميع الفصول أولاً قبل الاطلاع على تفاصيل الشخصيات الكاملة.
          </p>
        </div>

        <p className="text-muted-foreground text-sm mb-6">تابع على مسؤوليتك الخاصة.</p>

        <Button onClick={onAccept} className="w-full">
          فهمت، عرض الشخصيات
        </Button>
      </div>
    </div>
  )
}
