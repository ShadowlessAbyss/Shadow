"use client"

import { useState, useEffect } from "react"
import { ChevronLeft, ChevronRight } from "lucide-react"
import Link from "next/link"

const images = [
  {
    id: 1,
    title: "آخر فصل",
    type: "chapter",
    link: "/chapters",
    color: "from-indigo-600 to-purple-600",
    description: "اضغط للقراءة",
  },
  {
    id: 2,
    title: "الشخصية الأولى",
    type: "image",
    color: "from-purple-600 to-pink-600",
    description: "صورة الشخصية",
  },
  {
    id: 3,
    title: "الشخصية الثانية",
    type: "image",
    color: "from-pink-600 to-red-600",
    description: "صورة الشخصية",
  },
  {
    id: 4,
    title: "إعلان الكاتب",
    type: "image",
    color: "from-red-600 to-orange-600",
    description: "تابع الكاتب",
  },
]

export default function ImageSlider() {
  const [current, setCurrent] = useState(0)
  const [autoPlay, setAutoPlay] = useState(true)

  useEffect(() => {
    if (!autoPlay) return

    const interval = setInterval(() => {
      setCurrent((prev) => (prev + 1) % images.length)
    }, 5000)

    return () => clearInterval(interval)
  }, [autoPlay])

  const next = () => {
    setCurrent((prev) => (prev + 1) % images.length)
    setAutoPlay(false)
  }

  const prev = () => {
    setCurrent((prev) => (prev - 1 + images.length) % images.length)
    setAutoPlay(false)
  }

  const currentImage = images[current]

  return (
    <div className="relative w-full max-w-4xl mx-auto">
      <div className="relative h-96 rounded-2xl overflow-hidden border border-border/50">
        {images.map((image, index) => (
          <div
            key={image.id}
            className={`absolute inset-0 transition-opacity duration-500 ${
              index === current ? "opacity-100" : "opacity-0"
            }`}
          >
            {image.type === "chapter" ? (
              <Link href={image.link} className="w-full h-full block">
                <div
                  className={`w-full h-full bg-gradient-to-br ${image.color} flex items-center justify-center hover:opacity-90 transition-opacity cursor-pointer`}
                >
                  <div className="text-center">
                    <div className="text-6xl font-bold text-white mb-4">✦</div>
                    <h3 className="text-3xl font-bold text-white">{image.title}</h3>
                    <p className="text-sm text-white/80 mt-2">{image.description}</p>
                  </div>
                </div>
              </Link>
            ) : (
              <div className={`w-full h-full bg-gradient-to-br ${image.color} flex items-center justify-center`}>
                <div className="text-center">
                  <div className="text-6xl font-bold text-white mb-4">✦</div>
                  <h3 className="text-3xl font-bold text-white">{image.title}</h3>
                  <p className="text-sm text-white/80 mt-2">{image.description}</p>
                </div>
              </div>
            )}
          </div>
        ))}
      </div>

      {/* Navigation Buttons */}
      <button
        onClick={prev}
        className="absolute right-4 top-1/2 -translate-y-1/2 z-10 p-2 rounded-full bg-primary/60 hover:bg-primary text-white transition-all duration-300 hover:scale-110"
      >
        <ChevronRight size={24} />
      </button>

      <button
        onClick={next}
        className="absolute left-4 top-1/2 -translate-y-1/2 z-10 p-2 rounded-full bg-primary/60 hover:bg-primary text-white transition-all duration-300 hover:scale-110"
      >
        <ChevronLeft size={24} />
      </button>

      {/* Dots */}
      <div className="flex justify-center gap-2 mt-6">
        {images.map((_, index) => (
          <button
            key={index}
            onClick={() => {
              setCurrent(index)
              setAutoPlay(false)
            }}
            className={`w-3 h-3 rounded-full transition-all duration-300 ${
              index === current ? "bg-primary w-8" : "bg-muted hover:bg-muted-foreground"
            }`}
          />
        ))}
      </div>
    </div>
  )
}
