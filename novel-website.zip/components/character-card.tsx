"use client"

import { useState } from "react"
import { ChevronDown, Edit2, Trash2 } from "lucide-react"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Button } from "@/components/ui/button"

interface CharacterCardProps {
  id?: number
  name: string
  role: string
  description: string
  color: string
  quote: string
  spoilerLevel?: "low" | "medium" | "high"
  isAdmin?: boolean
  onEdit?: (id: number, data: any) => void
  onDelete?: (id: number) => void
}

export default function CharacterCard({
  id = 0,
  name,
  role,
  description,
  color,
  quote,
  spoilerLevel = "medium",
  isAdmin = false,
  onEdit,
  onDelete,
}: CharacterCardProps) {
  const [isExpanded, setIsExpanded] = useState(false)
  const [editName, setEditName] = useState(name)
  const [editRole, setEditRole] = useState(role)
  const [editDescription, setEditDescription] = useState(description)
  const [editQuote, setEditQuote] = useState(quote)

  const spoilerColors = {
    low: "border-green-500/30 bg-green-500/5",
    medium: "border-yellow-500/30 bg-yellow-500/5",
    high: "border-red-500/30 bg-red-500/5",
  }

  const spoilerLabels = {
    low: "حرق قليل",
    medium: "حرق متوسط",
    high: "حرق كبير",
  }

  return (
    <div className="group cursor-pointer">
      <div
        className={`relative p-6 rounded-2xl bg-gradient-to-br ${color} overflow-hidden transition-all duration-300 hover:scale-105 hover:shadow-lg`}
      >
        {/* Background glow */}
        <div className="absolute inset-0 bg-black/40 group-hover:bg-black/20 transition-colors" />

        <div
          className={`absolute top-4 left-4 px-2 py-1 rounded text-xs font-semibold border ${spoilerColors[spoilerLevel]}`}
        >
          {spoilerLabels[spoilerLevel]}
        </div>

        {/* Content */}
        <div className="relative z-10">
          <div className="w-16 h-16 rounded-full bg-white/20 backdrop-blur-sm mb-4 flex items-center justify-center text-3xl">
            ✦
          </div>

          <h3 className="text-2xl font-bold text-white mb-1">{name}</h3>
          <p className="text-white/80 text-sm mb-4">{role}</p>

          <div className={`overflow-hidden transition-all duration-300 ${isExpanded ? "max-h-96" : "max-h-0"}`}>
            <p className="text-white/90 text-sm leading-relaxed mb-4">{description}</p>
            <div className="border-t border-white/20 pt-4">
              <p className="text-white italic text-sm">"{quote}"</p>
            </div>
          </div>

          <div className="flex items-center justify-between mt-4">
            <span className="text-white/60 text-xs">{isExpanded ? "إخفاء التفاصيل" : "عرض التفاصيل"}</span>
            <div className="flex items-center gap-2">
              {isAdmin && (
                <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                  <Dialog>
                    <DialogTrigger asChild>
                      <button
                        onClick={(e) => e.stopPropagation()}
                        className="p-1 hover:bg-white/20 rounded transition-colors"
                      >
                        <Edit2 size={14} className="text-white" />
                      </button>
                    </DialogTrigger>
                    <DialogContent className="bg-card border-border/50">
                      <DialogHeader>
                        <DialogTitle>تعديل الشخصية</DialogTitle>
                      </DialogHeader>
                      <div className="space-y-4">
                        <div>
                          <Label htmlFor="edit-name">الاسم</Label>
                          <Input
                            id="edit-name"
                            value={editName}
                            onChange={(e) => setEditName(e.target.value)}
                            className="bg-input border-border/50"
                          />
                        </div>
                        <div>
                          <Label htmlFor="edit-role">الدور</Label>
                          <Input
                            id="edit-role"
                            value={editRole}
                            onChange={(e) => setEditRole(e.target.value)}
                            className="bg-input border-border/50"
                          />
                        </div>
                        <div>
                          <Label htmlFor="edit-description">الوصف</Label>
                          <textarea
                            id="edit-description"
                            value={editDescription}
                            onChange={(e) => setEditDescription(e.target.value)}
                            className="w-full p-2 rounded-lg bg-input border border-border/50 text-foreground"
                            rows={3}
                          />
                        </div>
                        <div>
                          <Label htmlFor="edit-quote">الاقتباس</Label>
                          <Input
                            id="edit-quote"
                            value={editQuote}
                            onChange={(e) => setEditQuote(e.target.value)}
                            className="bg-input border-border/50"
                          />
                        </div>
                        <Button
                          onClick={() => {
                            onEdit?.(id, {
                              name: editName,
                              role: editRole,
                              description: editDescription,
                              quote: editQuote,
                            })
                          }}
                          className="w-full"
                        >
                          حفظ التغييرات
                        </Button>
                      </div>
                    </DialogContent>
                  </Dialog>

                  <button
                    onClick={(e) => {
                      e.stopPropagation()
                      onDelete?.(id)
                    }}
                    className="p-1 hover:bg-red-500/20 rounded transition-colors"
                  >
                    <Trash2 size={14} className="text-red-400" />
                  </button>
                </div>
              )}
              <ChevronDown
                size={16}
                className={`text-white/60 transition-transform duration-300 cursor-pointer ${isExpanded ? "rotate-180" : ""}`}
                onClick={() => setIsExpanded(!isExpanded)}
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
