"use client"

import Link from "next/link"
import { Facebook, Instagram, Twitter, Mail } from "lucide-react"

export default function Footer() {
  return (
    <footer className="relative z-10 border-t border-border/50 bg-background/50 backdrop-blur-sm mt-20">
      <div className="container mx-auto px-4 md:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-8">
          {/* About */}
          <div>
            <h3 className="text-lg font-semibold mb-4 text-primary">عن الموقع</h3>
            <p className="text-muted-foreground leading-relaxed">
              موقع مخصص لعرض رواية ساحرة تجمع بين الأدب والفن البصري.
            </p>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="text-lg font-semibold mb-4 text-primary">روابط سريعة</h3>
            <ul className="space-y-2">
              <li>
                <Link href="/chapters" className="text-muted-foreground hover:text-primary transition-colors">
                  الفصول
                </Link>
              </li>
              <li>
                <Link href="/characters" className="text-muted-foreground hover:text-primary transition-colors">
                  الشخصيات
                </Link>
              </li>
              <li>
                <Link href="/about" className="text-muted-foreground hover:text-primary transition-colors">
                  الكاتب
                </Link>
              </li>
            </ul>
          </div>

          {/* Social Links */}
          <div>
            <h3 className="text-lg font-semibold mb-4 text-primary">تابعنا</h3>
            <div className="flex gap-4">
              <a
                href="#"
                className="w-10 h-10 rounded-full bg-card hover:bg-primary/20 flex items-center justify-center text-primary hover:text-accent transition-all duration-300 hover:scale-110"
              >
                <Facebook size={20} />
              </a>
              <a
                href="#"
                className="w-10 h-10 rounded-full bg-card hover:bg-primary/20 flex items-center justify-center text-primary hover:text-accent transition-all duration-300 hover:scale-110"
              >
                <Instagram size={20} />
              </a>
              <a
                href="#"
                className="w-10 h-10 rounded-full bg-card hover:bg-primary/20 flex items-center justify-center text-primary hover:text-accent transition-all duration-300 hover:scale-110"
              >
                <Twitter size={20} />
              </a>
              <a
                href="#"
                className="w-10 h-10 rounded-full bg-card hover:bg-primary/20 flex items-center justify-center text-primary hover:text-accent transition-all duration-300 hover:scale-110"
              >
                <Mail size={20} />
              </a>
            </div>
          </div>
        </div>

        {/* Copyright */}
        <div className="border-t border-border/50 pt-8 text-center text-muted-foreground">
          <p>© جميع الحقوق محفوظة للكاتب. كل نجمة هنا تشهد على عالمك الخاص.</p>
          <p className="text-sm mt-2">يمنع النسخ أو النقل دون إذن الكاتب</p>
        </div>
      </div>
    </footer>
  )
}
