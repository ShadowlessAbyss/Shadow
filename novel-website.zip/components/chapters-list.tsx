"use client"

import { useState } from "react"
import { Search, Plus, Edit2, Trash2 } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"

interface Chapter {
  id: number
  title: string
  number: number
}

interface ChaptersListProps {
  onSelectChapter: (id: number) => void
  selectedChapter: number | null
  isAdmin?: boolean
}

export default function ChaptersList({ onSelectChapter, selectedChapter, isAdmin = false }: ChaptersListProps) {
  const [search, setSearch] = useState("")
  const [chapters, setChapters] = useState<Chapter[]>([
    { id: 1, title: "الفصل الأول: البداية", number: 1 },
    { id: 2, title: "الفصل الثاني: الظلام", number: 2 },
    { id: 3, title: "الفصل الثالث: النور", number: 3 },
    { id: 4, title: "الفصل الرابع: الحقيقة", number: 4 },
    { id: 5, title: "الفصل الخامس: الاختيار", number: 5 },
  ])
  const [editingId, setEditingId] = useState<number | null>(null)
  const [editTitle, setEditTitle] = useState("")
  const [newChapterTitle, setNewChapterTitle] = useState("")

  const filtered = chapters.filter((ch) => ch.title.includes(search) || ch.number.toString().includes(search))

  const handleAddChapter = () => {
    if (newChapterTitle.trim()) {
      const newId = Math.max(...chapters.map((c) => c.id), 0) + 1
      const newNumber = Math.max(...chapters.map((c) => c.number), 0) + 1
      setChapters([...chapters, { id: newId, title: newChapterTitle, number: newNumber }])
      setNewChapterTitle("")
    }
  }

  const handleEditChapter = (id: number, newTitle: string) => {
    setChapters(chapters.map((ch) => (ch.id === id ? { ...ch, title: newTitle } : ch)))
    setEditingId(null)
    setEditTitle("")
  }

  const handleDeleteChapter = (id: number) => {
    setChapters(chapters.filter((ch) => ch.id !== id))
    if (selectedChapter === id) {
      onSelectChapter(chapters[0]?.id || 0)
    }
  }

  return (
    <div className="sticky top-24 space-y-4">
      {/* Search */}
      <div className="relative">
        <Search className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground" size={20} />
        <input
          type="text"
          placeholder="ابحث عن فصل..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="w-full pl-4 pr-10 py-2 rounded-lg bg-card border border-border/50 text-foreground placeholder-muted-foreground focus:outline-none focus:border-primary/50 transition-colors"
        />
      </div>

      {isAdmin && (
        <Dialog>
          <DialogTrigger asChild>
            <Button className="w-full gap-2 bg-transparent" variant="outline">
              <Plus size={18} />
              إضافة فصل جديد
            </Button>
          </DialogTrigger>
          <DialogContent className="bg-card border-border/50">
            <DialogHeader>
              <DialogTitle>إضافة فصل جديد</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <Label htmlFor="new-chapter">عنوان الفصل</Label>
                <Input
                  id="new-chapter"
                  value={newChapterTitle}
                  onChange={(e) => setNewChapterTitle(e.target.value)}
                  placeholder="مثال: الفصل السادس: النهاية"
                  className="bg-input border-border/50"
                />
              </div>
              <Button onClick={handleAddChapter} className="w-full">
                إضافة
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      )}

      {/* Chapters */}
      <div className="space-y-2 max-h-96 overflow-y-auto">
        {filtered.map((chapter) => (
          <div
            key={chapter.id}
            className={`flex items-center gap-2 p-3 rounded-lg transition-all duration-300 ${
              selectedChapter === chapter.id
                ? "bg-primary/20 border border-primary"
                : "bg-card/50 border border-border/50 hover:border-primary/50 hover:bg-card/80"
            }`}
          >
            <button onClick={() => onSelectChapter(chapter.id)} className="flex-1 text-right">
              <div className="font-semibold">{chapter.title}</div>
              <div className="text-sm text-muted-foreground">الفصل {chapter.number}</div>
            </button>

            {isAdmin && (
              <div className="flex gap-1">
                <Dialog>
                  <DialogTrigger asChild>
                    <button
                      onClick={() => {
                        setEditingId(chapter.id)
                        setEditTitle(chapter.title)
                      }}
                      className="p-1 hover:bg-primary/20 rounded transition-colors"
                    >
                      <Edit2 size={16} className="text-primary" />
                    </button>
                  </DialogTrigger>
                  <DialogContent className="bg-card border-border/50">
                    <DialogHeader>
                      <DialogTitle>تعديل الفصل</DialogTitle>
                    </DialogHeader>
                    <div className="space-y-4">
                      <div>
                        <Label htmlFor="edit-chapter">عنوان الفصل</Label>
                        <Input
                          id="edit-chapter"
                          value={editTitle}
                          onChange={(e) => setEditTitle(e.target.value)}
                          className="bg-input border-border/50"
                        />
                      </div>
                      <Button onClick={() => handleEditChapter(chapter.id, editTitle)} className="w-full">
                        حفظ
                      </Button>
                    </div>
                  </DialogContent>
                </Dialog>

                <button
                  onClick={() => handleDeleteChapter(chapter.id)}
                  className="p-1 hover:bg-destructive/20 rounded transition-colors"
                >
                  <Trash2 size={16} className="text-destructive" />
                </button>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  )
}
