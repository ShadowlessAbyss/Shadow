"use client"

import Link from "next/link"
import { useState } from "react"
import { Menu, X, Shield } from "lucide-react"

export default function Navigation() {
  const [isOpen, setIsOpen] = useState(false)

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 bg-background/80 backdrop-blur-md border-b border-border/50">
      <div className="container mx-auto px-4 md:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <Link href="/" className="flex items-center gap-2 group">
            <div className="w-8 h-8 rounded-full bg-gradient-to-br from-primary to-secondary flex items-center justify-center text-white font-bold text-glow">
              ✦
            </div>
            <span className="text-xl font-bold text-glow hidden sm:inline">الرواية</span>
          </Link>

          {/* Desktop Menu */}
          <div className="hidden md:flex items-center gap-8">
            <Link href="/" className="text-foreground/80 hover:text-primary transition-colors">
              الرئيسية
            </Link>
            <Link href="/chapters" className="text-foreground/80 hover:text-primary transition-colors">
              الفصول
            </Link>
            <Link href="/characters" className="text-foreground/80 hover:text-primary transition-colors">
              الشخصيات
            </Link>
            <Link href="/about" className="text-foreground/80 hover:text-primary transition-colors">
              الكاتب
            </Link>
          </div>

          <div className="hidden md:flex items-center gap-2 text-xs text-muted-foreground">
            <Shield size={16} className="text-green-500" />
            <span>محمي</span>
          </div>

          {/* Mobile Menu Button */}
          <button
            onClick={() => setIsOpen(!isOpen)}
            className="md:hidden p-2 hover:bg-card rounded-lg transition-colors"
          >
            {isOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>

        {/* Mobile Menu */}
        {isOpen && (
          <div className="md:hidden pb-4 space-y-2">
            <Link
              href="/"
              className="block px-4 py-2 text-foreground/80 hover:text-primary hover:bg-card rounded-lg transition-colors"
            >
              الرئيسية
            </Link>
            <Link
              href="/chapters"
              className="block px-4 py-2 text-foreground/80 hover:text-primary hover:bg-card rounded-lg transition-colors"
            >
              الفصول
            </Link>
            <Link
              href="/characters"
              className="block px-4 py-2 text-foreground/80 hover:text-primary hover:bg-card rounded-lg transition-colors"
            >
              الشخصيات
            </Link>
            <Link
              href="/about"
              className="block px-4 py-2 text-foreground/80 hover:text-primary hover:bg-card rounded-lg transition-colors"
            >
              الكاتب
            </Link>
          </div>
        )}
      </div>
    </nav>
  )
}
