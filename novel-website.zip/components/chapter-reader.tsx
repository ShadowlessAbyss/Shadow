"use client"

import { useEffect, useState } from "react"

const chapterContent: Record<number, string> = {
  1: `في ليلة مظلمة، حيث تتلألأ النجوم في السماء البعيدة، بدأت الرحلة. كان البطل يقف على حافة عالم جديد، مليء بالأسرار والغموض.

كل خطوة كانت تقربه من الحقيقة، وكل نفس كان يحمل معه أمل جديد. لم يكن يعرف ما ينتظره في الظلام، لكنه كان يعلم أنه يجب أن يمضي قدماً.

الليل كان ساحراً، والنجوم كانت تهمس له بأسرار القدم. كان يشعر بأن كل شيء قد تغير، وأن حياته لن تكون كما كانت من قبل.`,

  2: `الظلام كان يحيط به من كل جانب. لم يكن هناك ضوء، لا حتى خيط واحد من الأمل. لكن في قلب الظلام، وجد البطل قوة جديدة.

كانت هناك أصوات غريبة، همسات تأتي من العدم. كان يحاول فهمها، لكنها كانت بعيدة المنال. مع كل خطوة، كان يشعر بأنه يقترب من شيء ما، شيء مهم.

الخوف كان يتسلل إلى قلبه، لكنه لم يستسلم. كان يعلم أن هناك نور في نهاية النفق، وأنه يجب أن يجده.`,

  3: `وفجأة، ظهر النور. كان ضعيفاً في البداية، مجرد خيط رقيق من الأمل. لكنه كان هناك، حقيقياً وملموساً.

مع كل خطوة نحو النور، كان البطل يشعر بأن الظلام يتراجع. كانت الحقيقة تقترب، والأسرار تبدأ في الانكشاف. كان يرى الآن بوضوح، ويفهم ما كان مخفياً عنه.

النور لم يكن مجرد ضوء فيزيائي، بل كان ضوء الحقيقة، ضوء الفهم. وفي تلك اللحظة، أدرك البطل أن الرحلة الحقيقية قد بدأت للتو.`,

  4: `الحقيقة كانت أكثر تعقيداً مما توقع. لم تكن بسيطة أو واضحة، بل كانت متعددة الطبقات، مليئة بالتناقضات والألغاز.

كان هناك أشخاص آخرون في هذا العالم، كل واحد منهم يحمل قطعة من اللغز. كان البطل يجب أن يتعلم الثقة بهم، والعمل معهم لكشف الحقيقة الكاملة.

مع كل اكتشاف جديد، كان يشعر بأن فهمه للعالم يتغير. كانت الحقيقة ليست ما توقعها، لكنها كانت أكثر جمالاً وتعقيداً.`,

  5: `الآن حان وقت الاختيار. كان البطل يقف على مفترق طرق، وعليه أن يقرر أي طريق سيسلك.

كل خيار كان له عواقبه، كل قرار كان سيغير مسار الرحلة. كان يجب عليه أن يختار بحكمة، أن يستمع إلى قلبه وعقله معاً.

في تلك اللحظة، أدرك البطل أن الرحلة لم تكن عن الوصول إلى النهاية، بل عن الخيارات التي يتخذها في الطريق. وأن كل خيار يشكل من يصبح عليه.`,
}

interface ChapterReaderProps {
  chapterId: number
}

export default function ChapterReader({ chapterId }: ChapterReaderProps) {
  const [content, setContent] = useState("")

  useEffect(() => {
    setContent(chapterContent[chapterId] || "")
  }, [chapterId])

  return (
    <div className="animate-fade-in">
      <div className="p-8 rounded-2xl bg-card/50 backdrop-blur-sm border border-border/50">
        <div className="prose prose-invert max-w-none">
          <div className="space-y-6">
            {content.split("\n\n").map((paragraph, index) => (
              <p key={index} className="text-lg leading-relaxed text-foreground/90">
                {paragraph}
              </p>
            ))}
          </div>
        </div>

        {/* Navigation */}
        <div className="mt-8 pt-8 border-t border-border/50 flex justify-between">
          <button className="px-6 py-2 rounded-lg bg-primary/20 text-primary hover:bg-primary/30 transition-colors disabled:opacity-50">
            الفصل السابق
          </button>
          <button className="px-6 py-2 rounded-lg bg-primary/20 text-primary hover:bg-primary/30 transition-colors">
            الفصل التالي
          </button>
        </div>
      </div>

      <div className="mt-8 p-8 rounded-2xl bg-card/50 backdrop-blur-sm border border-border/50">
        <h3 className="text-2xl font-bold mb-6">التعليقات</h3>

        {/* Disqus Embed */}
        <div id={`disqus_thread_${chapterId}`} className="disqus-container">
          <script
            dangerouslySetInnerHTML={{
              __html: `
                (function() {
                  var d = document, s = d.createElement('script');
                  s.src = 'https://your-disqus-shortname.disqus.com/embed.js';
                  s.setAttribute('data-timestamp', +new Date());
                  (d.head || d.body).appendChild(s);
                })();
              `,
            }}
          />
        </div>

        <noscript>يرجى تفعيل JavaScript لعرض التعليقات</noscript>
      </div>
    </div>
  )
}
