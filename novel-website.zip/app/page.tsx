"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { Users, Mail, BookOpen } from "lucide-react"
import Navigation from "@/components/navigation"
import StarField from "@/components/star-field"
import ImageSlider from "@/components/image-slider"
import Footer from "@/components/footer"

export default function Home() {
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    setMounted(true)
  }, [])

  if (!mounted) return null

  return (
    <div className="min-h-screen bg-background text-foreground overflow-hidden">
      <StarField />
      <Navigation />

      {/* Hero Section */}
      <main className="relative z-10 pt-20 pb-16">
        <div className="container mx-auto px-4 md:px-8">
          {/* Title */}
          <div className="text-center mb-12 animate-fade-in">
            <h1 className="text-5xl md:text-7xl font-bold mb-4 text-glow">عالم الرواية</h1>
            <p className="text-xl md:text-2xl text-muted-foreground mb-8">رحلة ليلية ساحرة عبر صفحات الخيال والحقيقة</p>
          </div>

          {/* Story Summary */}
          <div className="max-w-3xl mx-auto mb-12 p-8 rounded-2xl bg-card/50 backdrop-blur-sm border border-border/50 hover:border-primary/50 transition-all duration-300">
            <p className="text-lg leading-relaxed text-foreground/90 mb-4">
              في ليلة مظلمة مليئة بالنجوم، تبدأ رحلة البطل عبر عالم مليء بالأسرار والغموض. كل فصل يكشف طبقة جديدة من
              الحقيقة، وكل شخصية تحمل قصة خاصة بها.
            </p>
            <p className="text-lg leading-relaxed text-foreground/90">
              هذا الموقع ليس مجرد مكان لقراءة الفصول، بل عالم بصري وسردي يدخلك إلى قلب القصة.
            </p>
          </div>

          {/* Image Slider */}
          <div className="mb-16">
            <ImageSlider />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-3xl mx-auto">
            <Link href="/chapters" className="group">
              <div className="p-6 rounded-2xl bg-card/50 backdrop-blur-sm border border-border/50 hover:border-primary/50 transition-all duration-300 hover:bg-card/80 cursor-pointer">
                <BookOpen className="w-8 h-8 mb-3 text-primary group-hover:text-accent transition-colors" />
                <h3 className="text-xl font-semibold mb-2">الفصول</h3>
                <p className="text-muted-foreground">اقرأ الفصول</p>
              </div>
            </Link>

            <Link href="/characters" className="group">
              <div className="p-6 rounded-2xl bg-card/50 backdrop-blur-sm border border-border/50 hover:border-secondary/50 transition-all duration-300 hover:bg-card/80 cursor-pointer">
                <Users className="w-8 h-8 mb-3 text-secondary group-hover:text-accent transition-colors" />
                <h3 className="text-xl font-semibold mb-2">الشخصيات</h3>
                <p className="text-muted-foreground">تعرف على أبطال القصة</p>
              </div>
            </Link>

            <Link href="/about" className="group">
              <div className="p-6 rounded-2xl bg-card/50 backdrop-blur-sm border border-border/50 hover:border-accent/50 transition-all duration-300 hover:bg-card/80 cursor-pointer">
                <Mail className="w-8 h-8 mb-3 text-accent group-hover:text-primary transition-colors" />
                <h3 className="text-xl font-semibold mb-2">الكاتب</h3>
                <p className="text-muted-foreground">تواصل معنا</p>
              </div>
            </Link>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
