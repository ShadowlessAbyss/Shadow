"use client"

import { useState } from "react"
import Navigation from "@/components/navigation"
import StarField from "@/components/star-field"
import Footer from "@/components/footer"
import ChaptersList from "@/components/chapters-list"
import ChapterReader from "@/components/chapter-reader"
import { Button } from "@/components/ui/button"
import { Lock } from "lucide-react"

export default function ChaptersPage() {
  const [selectedChapter, setSelectedChapter] = useState<number | null>(null)
  const [isAdmin, setIsAdmin] = useState(false)
  const [adminPassword, setAdminPassword] = useState("")
  const [showPasswordPrompt, setShowPasswordPrompt] = useState(false)
  const [passwordAttempt, setPasswordAttempt] = useState("")
  const [passwordError, setPasswordError] = useState("")

  const ADMIN_PASSWORD = "admin123"

  const handleAdminClick = () => {
    if (isAdmin) {
      setIsAdmin(false)
      setAdminPassword("")
      setShowPasswordPrompt(false)
    } else {
      setShowPasswordPrompt(true)
    }
  }

  const handlePasswordSubmit = () => {
    if (passwordAttempt === ADMIN_PASSWORD) {
      setIsAdmin(true)
      setAdminPassword(passwordAttempt)
      setShowPasswordPrompt(false)
      setPasswordAttempt("")
      setPasswordError("")
    } else {
      setPasswordError("كلمة المرور غير صحيحة")
      setPasswordAttempt("")
    }
  }

  return (
    <div className="min-h-screen bg-background text-foreground overflow-hidden">
      <StarField />
      <Navigation />

      <main className="relative z-10 pt-20 pb-16">
        <div className="container mx-auto px-4 md:px-8">
          <div className="flex justify-between items-center mb-12">
            <h1 className="text-5xl md:text-6xl font-bold text-glow text-center flex-1">الفصول</h1>

            <Button
              onClick={handleAdminClick}
              variant={isAdmin ? "default" : "outline"}
              className="ml-4 flex items-center gap-2"
            >
              <Lock size={16} />
              {isAdmin ? "إيقاف الإدارة" : "وضع الإدارة"}
            </Button>
          </div>

          {showPasswordPrompt && (
            <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 backdrop-blur-sm">
              <div className="bg-card border border-border/50 rounded-2xl p-8 max-w-sm w-full mx-4">
                <h2 className="text-2xl font-bold mb-4">وضع الإدارة</h2>
                <p className="text-muted-foreground mb-6">أدخل كلمة المرور للوصول إلى وضع الإدارة</p>

                <input
                  type="password"
                  value={passwordAttempt}
                  onChange={(e) => {
                    setPasswordAttempt(e.target.value)
                    setPasswordError("")
                  }}
                  onKeyPress={(e) => e.key === "Enter" && handlePasswordSubmit()}
                  placeholder="كلمة المرور"
                  className="w-full px-4 py-2 rounded-lg bg-background border border-border/50 text-foreground mb-4 focus:outline-none focus:border-primary/50"
                  autoFocus
                />

                {passwordError && <p className="text-red-500 text-sm mb-4">{passwordError}</p>}

                <div className="flex gap-4">
                  <Button onClick={handlePasswordSubmit} className="flex-1">
                    دخول
                  </Button>
                  <Button
                    onClick={() => {
                      setShowPasswordPrompt(false)
                      setPasswordAttempt("")
                      setPasswordError("")
                    }}
                    variant="outline"
                    className="flex-1"
                  >
                    إلغاء
                  </Button>
                </div>
              </div>
            </div>
          )}

          <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
            {/* Sidebar */}
            <div className="lg:col-span-1">
              <ChaptersList onSelectChapter={setSelectedChapter} selectedChapter={selectedChapter} isAdmin={isAdmin} />
            </div>

            {/* Reader */}
            <div className="lg:col-span-3">
              {selectedChapter ? (
                <ChapterReader chapterId={selectedChapter} />
              ) : (
                <div className="p-8 rounded-2xl bg-card/50 backdrop-blur-sm border border-border/50 text-center">
                  <p className="text-muted-foreground text-lg">اختر فصلاً لبدء القراءة</p>
                </div>
              )}
            </div>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
