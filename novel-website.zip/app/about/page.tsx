"use client"

import type React from "react"

import { useState } from "react"
import Navigation from "@/components/navigation"
import StarField from "@/components/star-field"
import Footer from "@/components/footer"
import { Mail, Phone, MapPin, Send, CheckCircle, AlertCircle } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"

export default function AboutPage() {
  const [formData, setFormData] = useState({ name: "", email: "", message: "" })
  const [submitStatus, setSubmitStatus] = useState<"idle" | "loading" | "success" | "error">("idle")
  const [errorMessage, setErrorMessage] = useState("")

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!formData.name || !formData.email || !formData.message) {
      setErrorMessage("يرجى ملء جميع الحقول")
      setSubmitStatus("error")
      return
    }

    setSubmitStatus("loading")
    setErrorMessage("")

    try {
      // Simulate API call
      await new Promise((resolve) => setTimeout(resolve, 1500))

      // In a real app, you would send this to your backend
      console.log("Form submitted:", formData)

      setSubmitStatus("success")
      setFormData({ name: "", email: "", message: "" })

      // Reset success message after 3 seconds
      setTimeout(() => setSubmitStatus("idle"), 3000)
    } catch (error) {
      setSubmitStatus("error")
      setErrorMessage("حدث خطأ أثناء إرسال الرسالة. يرجى المحاولة لاحقاً.")
    }
  }

  return (
    <div className="min-h-screen bg-background text-foreground overflow-hidden">
      <StarField />
      <Navigation />

      <main className="relative z-10 pt-20 pb-16">
        <div className="container mx-auto px-4 md:px-8">
          <h1 className="text-5xl md:text-6xl font-bold mb-12 text-glow text-center">الكاتب</h1>

          <div className="max-w-3xl mx-auto">
            {/* Author Card */}
            <div className="p-8 rounded-2xl bg-card/50 backdrop-blur-sm border border-border/50 mb-8 hover:border-primary/50 transition-all duration-300">
              <div className="flex flex-col md:flex-row gap-8 items-center md:items-start">
                {/* Avatar */}
                <div className="w-32 h-32 rounded-full bg-gradient-to-br from-primary to-secondary flex items-center justify-center text-5xl flex-shrink-0 shadow-lg">
                  ✦
                </div>

                {/* Info */}
                <div className="flex-1 text-center md:text-right">
                  <h2 className="text-3xl font-bold mb-2">اسم الكاتب</h2>
                  <p className="text-primary text-lg mb-4">كاتب وروائي</p>
                  <p className="text-foreground/80 leading-relaxed mb-6">
                    كاتب متخصص في الروايات الخيالية والغامضة. يؤمن بقوة الكلمات وتأثيرها على الروح. كل رواية يكتبها هي
                    رحلة عميقة إلى أعماق الإنسانية والخيال.
                  </p>

                  <div className="flex gap-4 justify-center md:justify-end">
                    <a
                      href="#"
                      className="px-4 py-2 rounded-lg bg-primary/20 text-primary hover:bg-primary/30 transition-colors text-sm"
                    >
                      تويتر
                    </a>
                    <a
                      href="#"
                      className="px-4 py-2 rounded-lg bg-secondary/20 text-secondary hover:bg-secondary/30 transition-colors text-sm"
                    >
                      إنستجرام
                    </a>
                  </div>
                </div>
              </div>
            </div>

            {/* About Section */}
            <div className="p-8 rounded-2xl bg-card/50 backdrop-blur-sm border border-border/50 mb-8 hover:border-primary/50 transition-all duration-300">
              <h3 className="text-2xl font-bold mb-4 text-primary">عن الرواية</h3>
              <p className="text-foreground/80 leading-relaxed mb-4">
                هذه الرواية هي نتاج سنوات من التفكير والكتابة. تجمع بين عناصر الخيال والواقع، وتستكشف أعمق أسرار الروح
                البشرية.
              </p>
              <p className="text-foreground/80 leading-relaxed">
                كل فصل يمثل خطوة في رحلة البطل نحو الحقيقة، وكل شخصية تحمل رسالة خاصة بها. الموقع نفسه هو امتداد
                للرواية، يجمع بين الأدب والفن البصري.
              </p>
            </div>

            {/* Contact Section */}
            <div className="p-8 rounded-2xl bg-card/50 backdrop-blur-sm border border-border/50 hover:border-primary/50 transition-all duration-300">
              <h3 className="text-2xl font-bold mb-6 text-primary">تواصل معنا</h3>

              {/* Contact Info */}
              <div className="space-y-4 mb-8">
                <div className="flex items-center gap-4 p-4 rounded-lg bg-background/50 hover:bg-background/80 transition-colors">
                  <Mail className="text-primary flex-shrink-0" size={24} />
                  <div>
                    <p className="text-sm text-muted-foreground">البريد الإلكتروني</p>
                    <a
                      href="mailto:contact@example.com"
                      className="text-foreground hover:text-primary transition-colors font-semibold"
                    >
                      contact@example.com
                    </a>
                  </div>
                </div>

                <div className="flex items-center gap-4 p-4 rounded-lg bg-background/50 hover:bg-background/80 transition-colors">
                  <Phone className="text-secondary flex-shrink-0" size={24} />
                  <div>
                    <p className="text-sm text-muted-foreground">الهاتف</p>
                    <a
                      href="tel:+966501234567"
                      className="text-foreground hover:text-secondary transition-colors font-semibold"
                    >
                      +966 50 123 4567
                    </a>
                  </div>
                </div>

                <div className="flex items-center gap-4 p-4 rounded-lg bg-background/50 hover:bg-background/80 transition-colors">
                  <MapPin className="text-accent flex-shrink-0" size={24} />
                  <div>
                    <p className="text-sm text-muted-foreground">الموقع</p>
                    <p className="text-foreground font-semibold">المملكة العربية السعودية</p>
                  </div>
                </div>
              </div>

              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <Label htmlFor="name">الاسم</Label>
                  <Input
                    id="name"
                    name="name"
                    type="text"
                    placeholder="أدخل اسمك"
                    value={formData.name}
                    onChange={handleInputChange}
                    className="bg-background border-border/50"
                  />
                </div>

                <div>
                  <Label htmlFor="email">البريد الإلكتروني</Label>
                  <Input
                    id="email"
                    name="email"
                    type="email"
                    placeholder="أدخل بريدك الإلكتروني"
                    value={formData.email}
                    onChange={handleInputChange}
                    className="bg-background border-border/50"
                  />
                </div>

                <div>
                  <Label htmlFor="message">الرسالة</Label>
                  <textarea
                    id="message"
                    name="message"
                    placeholder="اكتب رسالتك هنا"
                    rows={4}
                    value={formData.message}
                    onChange={handleInputChange}
                    className="w-full px-4 py-2 rounded-lg bg-background border border-border/50 text-foreground placeholder-muted-foreground focus:outline-none focus:border-primary/50 transition-colors resize-none"
                  />
                </div>

                {/* Status Messages */}
                {submitStatus === "error" && (
                  <div className="flex items-center gap-2 p-4 rounded-lg bg-destructive/10 border border-destructive/30">
                    <AlertCircle size={20} className="text-destructive flex-shrink-0" />
                    <p className="text-destructive text-sm">{errorMessage}</p>
                  </div>
                )}

                {submitStatus === "success" && (
                  <div className="flex items-center gap-2 p-4 rounded-lg bg-green-500/10 border border-green-500/30">
                    <CheckCircle size={20} className="text-green-500 flex-shrink-0" />
                    <p className="text-green-500 text-sm">تم إرسال رسالتك بنجاح! شكراً لتواصلك معنا.</p>
                  </div>
                )}

                <Button type="submit" disabled={submitStatus === "loading"} className="w-full gap-2">
                  {submitStatus === "loading" ? (
                    <>
                      <div className="w-4 h-4 border-2 border-primary-foreground border-t-transparent rounded-full animate-spin" />
                      جاري الإرسال...
                    </>
                  ) : (
                    <>
                      <Send size={18} />
                      إرسال الرسالة
                    </>
                  )}
                </Button>
              </form>
            </div>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
