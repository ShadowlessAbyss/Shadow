"use client"

import { useState, useEffect } from "react"
import Navigation from "@/components/navigation"
import StarField from "@/components/star-field"
import Footer from "@/components/footer"
import CharacterCard from "@/components/character-card"
import WarningModal from "@/components/warning-modal"
import { Button } from "@/components/ui/button"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Plus } from "lucide-react"

interface Character {
  id: number
  name: string
  role: string
  description: string
  color: string
  quote: string
  spoilerLevel: "low" | "medium" | "high"
}

export default function CharactersPage() {
  const [showWarning, setShowWarning] = useState(true)
  const [isAdmin, setIsAdmin] = useState(false)
  const [characters, setCharacters] = useState<Character[]>([
    {
      id: 1,
      name: "البطل",
      role: "الشخصية الرئيسية",
      description: "شاب يبحث عن الحقيقة في عالم مليء بالظلام والغموض",
      color: "from-blue-500 to-cyan-500",
      quote: "في الظلام، وجدت نوري الخاص",
      spoilerLevel: "low",
    },
    {
      id: 2,
      name: "الحكيمة",
      role: "الموجهة",
      description: "امرأة عرفت الحقيقة منذ زمن بعيد، وتسعى لمساعدة الآخرين",
      color: "from-purple-500 to-pink-500",
      quote: "الحقيقة ليست دائماً ما نتوقعها",
      spoilerLevel: "medium",
    },
    {
      id: 3,
      name: "الظل",
      role: "الخصم الغامض",
      description: "قوة غامضة تحاول منع البطل من الوصول إلى الحقيقة",
      color: "from-red-500 to-orange-500",
      quote: "الظلام هو موطني الحقيقي",
      spoilerLevel: "high",
    },
    {
      id: 4,
      name: "الرفيق",
      role: "صديق البطل",
      description: "شخص يقف بجانب البطل في كل خطوة من الرحلة",
      color: "from-green-500 to-emerald-500",
      quote: "لن تكون وحيداً في هذه الرحلة",
      spoilerLevel: "low",
    },
    {
      id: 5,
      name: "الساحرة",
      role: "حارسة الأسرار",
      description: "تمتلك معرفة قديمة عن أصول العالم والقوى الخفية",
      color: "from-indigo-500 to-violet-500",
      quote: "الأسرار لها ثمن",
      spoilerLevel: "high",
    },
    {
      id: 6,
      name: "الملك",
      role: "حاكم العالم",
      description: "يسيطر على كل شيء، لكن أهدافه الحقيقية غير واضحة",
      color: "from-yellow-500 to-amber-500",
      quote: "السلطة هي الحقيقة الوحيدة",
      spoilerLevel: "medium",
    },
  ])

  useEffect(() => {
    const seen = localStorage.getItem("spoiler-warning-seen")
    if (seen) {
      setShowWarning(false)
    }
  }, [])

  const handleAcceptWarning = () => {
    localStorage.setItem("spoiler-warning-seen", "true")
    setShowWarning(false)
  }

  const handleEditCharacter = (id: number, data: any) => {
    setCharacters(characters.map((ch) => (ch.id === id ? { ...ch, ...data } : ch)))
  }

  const handleDeleteCharacter = (id: number) => {
    setCharacters(characters.filter((ch) => ch.id !== id))
  }

  const handleAddCharacter = (newCharacter: Omit<Character, "id">) => {
    const newId = Math.max(...characters.map((c) => c.id), 0) + 1
    setCharacters([...characters, { ...newCharacter, id: newId }])
  }

  return (
    <div className="min-h-screen bg-background text-foreground overflow-hidden">
      <StarField />
      <Navigation />

      {showWarning && <WarningModal onAccept={handleAcceptWarning} onDismiss={() => setShowWarning(false)} />}

      <main
        className={`relative z-10 pt-20 pb-16 transition-opacity duration-500 ${showWarning ? "opacity-50 pointer-events-none" : "opacity-100"}`}
      >
        <div className="container mx-auto px-4 md:px-8">
          <div className="flex justify-between items-center mb-12">
            <h1 className="text-5xl md:text-6xl font-bold text-glow text-center flex-1">الشخصيات</h1>
            <Button onClick={() => setIsAdmin(!isAdmin)} variant={isAdmin ? "default" : "outline"} className="ml-4">
              {isAdmin ? "إيقاف الإدارة" : "وضع الإدارة"}
            </Button>
          </div>

          {isAdmin && (
            <div className="mb-8 flex justify-end">
              <Dialog>
                <DialogTrigger asChild>
                  <Button className="gap-2">
                    <Plus size={18} />
                    إضافة شخصية جديدة
                  </Button>
                </DialogTrigger>
                <DialogContent className="bg-card border-border/50">
                  <DialogHeader>
                    <DialogTitle>إضافة شخصية جديدة</DialogTitle>
                  </DialogHeader>
                  <AddCharacterForm onAdd={handleAddCharacter} />
                </DialogContent>
              </Dialog>
            </div>
          )}

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {characters.map((character) => (
              <CharacterCard
                key={character.id}
                id={character.id}
                name={character.name}
                role={character.role}
                description={character.description}
                color={character.color}
                quote={character.quote}
                spoilerLevel={character.spoilerLevel}
                isAdmin={isAdmin}
                onEdit={handleEditCharacter}
                onDelete={handleDeleteCharacter}
              />
            ))}
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}

function AddCharacterForm({ onAdd }: { onAdd: (character: Omit<Character, "id">) => void }) {
  const [name, setName] = useState("")
  const [role, setRole] = useState("")
  const [description, setDescription] = useState("")
  const [quote, setQuote] = useState("")
  const [spoilerLevel, setSpoilerLevel] = useState<"low" | "medium" | "high">("medium")
  const [color, setColor] = useState("from-blue-500 to-cyan-500")

  const colors = [
    "from-blue-500 to-cyan-500",
    "from-purple-500 to-pink-500",
    "from-red-500 to-orange-500",
    "from-green-500 to-emerald-500",
    "from-indigo-500 to-violet-500",
    "from-yellow-500 to-amber-500",
  ]

  return (
    <div className="space-y-4">
      <div>
        <Label htmlFor="name">الاسم</Label>
        <Input id="name" value={name} onChange={(e) => setName(e.target.value)} className="bg-input border-border/50" />
      </div>
      <div>
        <Label htmlFor="role">الدور</Label>
        <Input id="role" value={role} onChange={(e) => setRole(e.target.value)} className="bg-input border-border/50" />
      </div>
      <div>
        <Label htmlFor="description">الوصف</Label>
        <textarea
          id="description"
          value={description}
          onChange={(e) => setDescription(e.target.value)}
          className="w-full p-2 rounded-lg bg-input border border-border/50 text-foreground"
          rows={3}
        />
      </div>
      <div>
        <Label htmlFor="quote">الاقتباس</Label>
        <Input
          id="quote"
          value={quote}
          onChange={(e) => setQuote(e.target.value)}
          className="bg-input border-border/50"
        />
      </div>
      <div>
        <Label htmlFor="spoiler">مستوى الحرق</Label>
        <select
          id="spoiler"
          value={spoilerLevel}
          onChange={(e) => setSpoilerLevel(e.target.value as "low" | "medium" | "high")}
          className="w-full p-2 rounded-lg bg-input border border-border/50 text-foreground"
        >
          <option value="low">حرق قليل</option>
          <option value="medium">حرق متوسط</option>
          <option value="high">حرق كبير</option>
        </select>
      </div>
      <div>
        <Label>اللون</Label>
        <div className="grid grid-cols-3 gap-2">
          {colors.map((c) => (
            <button
              key={c}
              onClick={() => setColor(c)}
              className={`h-10 rounded-lg bg-gradient-to-br ${c} border-2 ${color === c ? "border-white" : "border-transparent"}`}
            />
          ))}
        </div>
      </div>
      <Button
        onClick={() =>
          onAdd({
            name,
            role,
            description,
            quote,
            spoilerLevel,
            color,
          })
        }
        className="w-full"
      >
        إضافة الشخصية
      </Button>
    </div>
  )
}
